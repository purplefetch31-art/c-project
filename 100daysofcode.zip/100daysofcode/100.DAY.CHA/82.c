/* Q82: Print each character of a string on a new line.

Sample Test Cases:
Input 1:
Hi
Output 1:
H
i
*/
#include <stdio.h>

int main() {
    char str[101];
    int i = 0;

    fgets(str, sizeof(str), stdin);

    while (str[i] != '\n' && str[i] != '\0') {
        printf("%c\n", str[i]);
        i++;
    }
    return 0;
}